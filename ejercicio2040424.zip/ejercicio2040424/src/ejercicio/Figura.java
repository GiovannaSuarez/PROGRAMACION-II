package ejercicio;

public interface Figura {
    public float area();

}
