package ejercicio;

public interface Dibujable {
    public void dibujar();
}
