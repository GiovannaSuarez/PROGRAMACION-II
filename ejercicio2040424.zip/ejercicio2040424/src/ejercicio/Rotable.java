package ejercicio;

public interface Rotable {
    public void rotar ();
}
